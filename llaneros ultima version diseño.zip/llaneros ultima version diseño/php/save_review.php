<?php
include 'conexion.php';
session_start();

// Verificar si hay usuario logueado
if (!isset($_SESSION['cod_cli'])) {
    echo json_encode(['status' => 'error', 'message' => 'Usuario no autenticado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$cod_res = uniqid('rev_');
$desc_res = $data['text'];
$calif_res = $data['rating'];
$cod_prod = $data['productId'] ?: null;
$cod_cli = $_SESSION['cod_cli'];

$query = "INSERT INTO resenas (cod_res, desc_res, calif_res, cod_prod, cod_cli) 
          VALUES (?, ?, ?, ?, ?)";

$stmt = $conexion->prepare($query);
$stmt->bind_param("ssiss", $cod_res, $desc_res, $calif_res, $cod_prod, $cod_cli);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => $conexion->error]);
}

$stmt->close();
$conexion->close();
?>
