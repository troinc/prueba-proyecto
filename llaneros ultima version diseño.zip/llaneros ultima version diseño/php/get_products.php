<?php
include 'conexion.php';

$query = "SELECT cod_prod, nom_prod FROM productos";
$result = $conexion->query($query);

$products = array();
while($row = $result->fetch_assoc()) {
    $products[] = $row;
}

header('Content-Type: application/json');
echo json_encode($products);

$conexion->close();
?>
