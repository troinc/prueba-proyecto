<?php
session_start();
header('Content-Type: application/json');

// Verifica autenticación (aquí se supone que se encuentra user_id en la sesión)
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Usuario no autenticado']);
    exit;
}

// Recibe datos del producto en formato JSON
$data = json_decode(file_get_contents('php://input'), true);
if (!$data || !isset($data['name']) || !isset($data['price'])) {
    echo json_encode(['status' => 'error', 'message' => 'Datos incompletos']);
    exit;
}

$productId = isset($data['id']) ? $data['id'] : null;
$name = $data['name'];
$price = $data['price'];
$image = isset($data['image']) ? $data['image'] : '';
$quantity = isset($data['quantity']) ? (int)$data['quantity'] : 1;
$userId = $_SESSION['user_id'];

// Conexión a la base de datos
include 'conexion.php';

// Inserta o actualiza el producto en el carrito (en este ejemplo inserción simple)
$stmt = $conexion->prepare("INSERT INTO carrito (user_id, product_id, name, price, image, quantity) VALUES (?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    echo json_encode(['status' => 'error', 'message' => 'Error en la preparación: ' . $conexion->error]);
    exit;
}
$stmt->bind_param("issssi", $userId, $productId, $name, $price, $image, $quantity);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Producto guardado correctamente']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error al guardar: ' . $stmt->error]);
}

$stmt->close();
$conexion->close();
?>
