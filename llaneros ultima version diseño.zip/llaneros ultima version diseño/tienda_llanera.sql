-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-03-2025 a las 02:38:55
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_llanera`
--

-- --------------------------------------------------------
-- Eliminar tablas antiguas
DROP TABLE IF EXISTS `compras`;
DROP TABLE IF EXISTS `productos_proveedores`;
DROP TABLE IF EXISTS `proveedores`;

-- --------------------------------------------------------
--
-- Estructura de tabla para la tabla `categorias`
--
CREATE TABLE `categorias` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `cod_cat` VARCHAR(50) UNIQUE NOT NULL,
  `nom_cat` VARCHAR(100) NOT NULL,
  `desc_cat` TEXT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- --------------------------------------------------------
--
-- Estructura de tabla para la tabla `clientes`
--
CREATE TABLE `clientes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `cod_cli` VARCHAR(50) UNIQUE NOT NULL,
  `nom_cli` VARCHAR(100) NOT NULL,
  `ape_cli` VARCHAR(100) NOT NULL,
  `email_cli` VARCHAR(100) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `fec_registro` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- --------------------------------------------------------
--
-- Nueva estructura para pedidos y detalles
--
CREATE TABLE `pedidos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `num_ped` VARCHAR(50) UNIQUE NOT NULL,
  `fec_compra` DATE NOT NULL,
  `estado_ped` VARCHAR(50) DEFAULT 'pendiente',
  `cod_cli` VARCHAR(50) NOT NULL,
  FOREIGN KEY (`cod_cli`) REFERENCES `clientes`(`cod_cli`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

CREATE TABLE `detalles_pedido` (
  `id_pedido` INT NOT NULL,
  `cod_prod` VARCHAR(50) NOT NULL,
  `cantidad` INT NOT NULL DEFAULT 1,
  `precio_unitario` DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`id_pedido`, `cod_prod`),
  FOREIGN KEY (`id_pedido`) REFERENCES `pedidos`(`id`),
  FOREIGN KEY (`cod_prod`) REFERENCES `productos`(`cod_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- --------------------------------------------------------
--
-- Estructura de tabla para la tabla `productos`
--
CREATE TABLE `productos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `cod_prod` VARCHAR(50) UNIQUE NOT NULL,
  `nom_prod` VARCHAR(100) NOT NULL,
  `desc_prod` TEXT DEFAULT NULL,
  `precio_prod` DECIMAL(10,2) NOT NULL,
  `stock_prod` INT NOT NULL DEFAULT 0,
  `cod_cat` VARCHAR(50) DEFAULT NULL,
  FOREIGN KEY (`cod_cat`) REFERENCES `categorias`(`cod_cat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- --------------------------------------------------------
--
-- Estructura de tabla para la tabla `resenas`
--
CREATE TABLE `resenas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `cod_res` VARCHAR(50) UNIQUE NOT NULL,
  `desc_res` TEXT DEFAULT NULL,
  `calif_res` ENUM('1', '2', '3', '4', '5') NOT NULL,
  `cod_prod` VARCHAR(50) NOT NULL,
  `cod_cli` VARCHAR(50) NOT NULL,
  `fec_resena` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`cod_prod`) REFERENCES `productos`(`cod_prod`),
  FOREIGN KEY (`cod_cli`) REFERENCES `clientes`(`cod_cli`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- --------------------------------------------------------
--
-- Índices adicionales
--
CREATE INDEX idx_fec_compra ON pedidos(fec_compra);
CREATE INDEX idx_cod_cat ON productos(cod_cat);
CREATE INDEX idx_precio ON productos(precio_prod);

-- --------------------------------------------------------
--
-- Restricciones adicionales
--
ALTER TABLE `clientes`
ADD CONSTRAINT chk_email CHECK (email_cli LIKE '%@%.%');

ALTER TABLE `productos`
ADD CONSTRAINT chk_precio_positivo CHECK (precio_prod > 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;